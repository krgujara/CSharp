﻿/////////////////////////////////////////////////////////
// BuildServer.cs - Responsible to build the test files
// Author - Komal Gujarathi, krgujara@syr.edu, 3157446116
// Application - Software Modeling CSE 681 
// Environment - C# 6.0 in Visual Studio 2017
////////////////////////////////////////////////////////

/* 
 * Package Operations
 * Build Server Prototype to build the solution programatically
 * 
 * Required Files 
 * ------------------
 * BuildServer.cs
 * .sln file that has to be built
 * 
 * Maintainance History
 * ---------------------
 * ver 1.0 : 13/sept/2017
 * - first release
 */

using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
namespace BuildServerPrototype
{
    class BuildServer
    {
        public string repoPath { set; get; } = "../../Repository";

        //---------< get File names in a directory> --------------
        private string[] getFileNames(string path, string pattern)        {            string[] tempFiles = Directory.GetFiles(path, pattern);
            for (int i = 0; i < tempFiles.Length; ++i)                Console.Write(tempFiles[i] + "\n");            return tempFiles;        }

        // -----------< get directories and the sub directories >-------
        private List<string> getDirectories(string path, string pattern)
        {            string[] directories = Directory.GetDirectories(path);            List<string> slnPaths = new List<string>();            foreach (string dir in directories)                slnPaths.Add(getFileNames(dir, pattern)[0]);            return slnPaths;
        }        // -------< build the files using Process Library>--------        private void build(string filePath, string format)        {            try
            {                 Process process = new Process();                ProcessStartInfo startInfo = new ProcessStartInfo();                if (format.Equals("*.sln"))
                    startInfo.FileName = "msbuild";
                startInfo.Arguments = filePath;                startInfo.UseShellExecute = false;                startInfo.RedirectStandardOutput = true;                process.StartInfo = startInfo;                process.Start();
                string output = process.StandardOutput.ReadToEnd();                Console.Write("Process exit code of above file is {0} : ", process.ExitCode);
                Console.Write("Build Report : \n\n: {0} \n\n",output );
            }
            catch (Exception ex)
            {
                Console.Write("there is an exception {0} \n\n", ex.Message);
            }
        }
        /*-----------------------<Build the files of given pattern>-----------------------*/
        public void buildFiles()
        {            Console.Write("Building following files\n\n");            Console.Write("========================================================\n");
            List<string> slnPaths = getDirectories(repoPath, "*.sln");//assuming all sln in project directory
            Console.Write("\n===================================================\n");
            foreach (string sln in slnPaths)
            {                Console.Write("Building {0} file \n", sln);                Console.Write("=======================================================\n");
                build(sln, "*.sln");
            }        }
    }


    class BuildServerTest
    {

        #if (TEST_BUILDSERVER)
        static void Main(string[] args)
        {
            // builds the sln files
            BuildServer bs = new BuildServer();
            bs.buildFiles();
            
        }
        #endif
    }
}
